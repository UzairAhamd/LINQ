﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Linq;
namespace Task5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] amount = { 5, 1, 9, 2, 3, 7, 4, 5, 6, 8, 7, 6, 3, 4, 5, 2 };
            List<int> quantity = new List<int>();
            List<int> totalAmount = new List<int>();
            Random random = new Random();
            foreach (int a in amount)
            {
                quantity.Add(random.Next(1,9));
            }
            Console.WriteLine();
            var amountQuery =
                from a in amount select a;
            var quantitQuery =
                from q in quantity select q;
            foreach (var (aQ, qQ) in amountQuery.Zip(quantitQuery))
            {
                Console.WriteLine("{0} {1} : {2}",aQ,qQ,aQ*qQ);
            }
        }
    }
}
