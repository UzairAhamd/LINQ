﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Linq;
namespace Task4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string String = "Illiahana".ToLower();
            var letterFrequency =
                from character in String
                group character by character into charFreq
                select charFreq;
            foreach (var freq in letterFrequency)
            {
                Console.WriteLine(freq.Key+" : "+freq.Count());
            }
        }
    }
}