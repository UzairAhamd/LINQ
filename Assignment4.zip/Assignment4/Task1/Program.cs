﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Linq;
namespace Task1
{
    public class Student
    {
        public string name;
        public int Id;
        public int age;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            List<Student> studentList = new List<Student>()
            {
                new Student{name="John",Id=101,age=20},
                new Student{name="Uraiz",Id=105,age=18},
                new Student{name="Ivan",Id=104,age=21},
                new Student{name="Zunair",Id=111,age=17},
                new Student{name="Uzaif",Id=107,age=19},
            };
            var teenAge =
                from std in studentList where std.age<20 && std.age >12 
                select std;
            foreach (var teen in teenAge)
            {
                Console.WriteLine("{0} {1} {2}",teen.name, teen.Id,teen.age);
            }
        }
    }
}