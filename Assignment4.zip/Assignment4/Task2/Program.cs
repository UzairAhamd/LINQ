﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Linq;
namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6 };
            var even = numbers.Where(x => x % 2 == 0).ToList();
            foreach(var e in even)
            {
                Console.Write(e+" ");
            }
        }
    }
}