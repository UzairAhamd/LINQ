﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Linq;
namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = {"Muaz","Mendi","Rahib","Allie","Umama","Mark","Iliah"};
            var firstLetterM = names.Where(x => x[0] == 'M').ToList();
            foreach (var m in firstLetterM)
            {
                Console.Write(m + " ");
            }
        }
    }
}