﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task1
{
    public class Student        //Student class having name, Id, age as its members 
    {
        public string name;
        public int Id;
        public int age;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //studentList is a list of type Student object with students data
            List<Student> studentList = new List<Student>()
            {
                new Student{name="John",Id=101,age=20},
                new Student{name="Uraiz",Id=105,age=18},
                new Student{name="Ivan",Id=104,age=21},
                new Student{name="Zunair",Id=111,age=17},
                new Student{name="Uzaif",Id=107,age=19},
            };
            var teenAge =               //query the studentList with students having ages from 13 to 19
                from std in studentList
                where std.age < 20 && std.age > 12
                select std;
            Console.WriteLine("{0,-10}{1,-10}{2}", "Name", "Id", "Age");
            Console.WriteLine("-----------------------------");
            foreach (var teen in teenAge)
            {
                Console.WriteLine("{0,-10}{1,-10}{2}", teen.name, teen.Id, teen.age);         //print the teen students' data
            }
        }
    }
}