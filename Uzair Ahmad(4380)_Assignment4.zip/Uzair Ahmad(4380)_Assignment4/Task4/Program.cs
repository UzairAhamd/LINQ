﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string String = "Illiahana".ToLower();      //take a string of characters and lower its case
            var letterFrequency =           //letterFrequncy to query the characters in the string and their frequncy as well
                from character in String
                group character by character into charFreq
                select charFreq;
            Console.WriteLine("{0,-20}{1}", "Characater", "Frequency");
            Console.WriteLine("--------------------------------");
            foreach (var freq in letterFrequency)
            {
                Console.WriteLine("{0,-20}{1}", freq.Key, freq.Count());    //ouput the character and its frequncy
            }
        }
    }
}