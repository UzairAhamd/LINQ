﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] names = { "Muaz", "Mendi", "Rahib", "Allie", "Umama", "Mark", "Iliah" };   //take the names array
            var firstLetterM = names.Where(x => x[0] == 'M').ToList();      //use lambda functon to query the letters starting with M and list them down
            Console.WriteLine("Names starting with letter M are: ");
            foreach (var m in firstLetterM)
            {
                Console.Write("{0,-10}", m);        //ouput the names starting with M
            }
            Console.Write("\b\b\b\b\b\b ");            //remove the extra spaces
        }
    }
}