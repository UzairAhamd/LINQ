﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task7
{
    //Student class having name, Id, age, marks as its members 
    public class Student
    {
        public string name;
        public int Id;
        public int age;
        public int marks;
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            //studentList is a list of type Student object with 10 students data
            List<Student> studentList = new List<Student>()
            {
                new Student{name="John",Id=101,age=20, marks=80},
                new Student{name="Uraiz",Id=105,age=18, marks=70},
                new Student{name="Ivan",Id=104,age=21, marks=90},
                new Student{name="Zunair",Id=111,age=17, marks=95},
                new Student{name="Uzaif",Id=107,age=19, marks=85},
                new Student{name="Mark",Id=102,age=20, marks=75},
                new Student{name="Jerry",Id=106,age=18, marks=90},
                new Student{name="Tom",Id=108,age=21, marks=70},
                new Student{name="James",Id=110,age=17, marks=65},
                new Student{name="Peter",Id=103,age=19, marks=80},
            };
            //remove the first two positions from the list
            studentList.RemoveRange(0, 2);
            //show the processed studendList
            Console.WriteLine("{0,-10}{1,-10}{2,-10}{3}", "Name","Id","Age","Marks");
            Console.WriteLine("------------------------------------");
            foreach (var student in studentList)
            {
                Console.WriteLine("{0,-10}{1,-10}{2,-10}{3}", student.name, student.Id, student.age, student.marks);
            }
        }
    }
}