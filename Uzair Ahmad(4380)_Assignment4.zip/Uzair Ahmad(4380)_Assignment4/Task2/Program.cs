﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6 };   //take an array of numbers
            var even = numbers.Where(x => x % 2 == 0).ToList();     //use lambda function to have the even numbers and root them to even list
            foreach (var e in even)
            {
                Console.Write(e + " ");     //print each even number
            }
            Console.Write("\b ");   //remove extra backspace
        }
    }
}