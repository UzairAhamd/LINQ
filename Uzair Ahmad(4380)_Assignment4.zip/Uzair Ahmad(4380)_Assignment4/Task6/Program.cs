﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task6
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create an array of numbers
            int[] numbers = { 5, 1, -9, 2, 3, -7, 4, 8, 5, 6, 8};
            //use OrderByDescending method on numbers array and get the top3 distinct numbers
            var topQuery = numbers.OrderByDescending(x => x).Distinct().Take(3);
            Console.Write("Top three numbres in: {");
            //output the numbers array
            foreach (var num in numbers)
            {
                Console.Write(num + ", ");
            }
            Console.Write("\b\b} are: "); //remove the extra comma and space
            Console.WriteLine();
            //output the processed numbers
            foreach(var top in topQuery)
            {
                Console.Write(top+", ");
            }
            Console.Write("\b\b");  //remove the extra comma and space
        }
    }
}
