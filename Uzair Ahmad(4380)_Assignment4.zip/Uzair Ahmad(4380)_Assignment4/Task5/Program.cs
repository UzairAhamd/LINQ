﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Get the amount list from the user one by one 
            Console.WriteLine("Please Enter the Items Amount List:"); 
            List<int> amount = new List<int>(); //create an empty amount list to get values from user
            bool checkList = false;
            int i = 1;
            while (checkList == false)  //until the user don't want to enter more values
            {
                Console.Write("Enter Amount " + i + " :");
                amount.Add(Convert.ToInt32(Console.ReadLine()));        //add the entered amount value to amount list
                i++;
                Console.Write("Do you want to enter more elements? (y/n): ");
                string checkResponse = Console.ReadLine();
                if (checkResponse == "n")
                {
                    checkList = true;
                }
            }
            List<int> quantity = new List<int>();   //quantity is a new list to hold the quantity of itmes
            List<int> totalAmount = new List<int>();    //totalAmount is a new list to store the total price for a quantity
            Random random = new Random();
            foreach (int a in amount)
            {
                quantity.Add(random.Next(1, 9));    //generate a random number inbetween 1 and 9 then add in the quantity list
                Console.Write(a + ", ");
            }
            Console.Write("\b\b "); //remove the extra comma and space
            Console.WriteLine();
            var amountQuery =               //amountQuery to select each amount
                from a in amount select a;
            var quantitQuery =              //quantityQuery to select each quantity
                from q in quantity select q;
            Console.WriteLine("{0,-10}{1,-10}{2}", "Amount", "Qty", "Total");
            Console.WriteLine("----------------------------------------------------");
            foreach (var (aQ, qQ) in amountQuery.Zip(quantitQuery))     //Zip function to iterate through lists simultaneously 
            {
                Console.WriteLine("{0,-10}{1,-10}{2}", aQ, qQ, aQ * qQ);    //ouput the total for an item
            }
        }
    }
}
