﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task1
{
    class Program
    {
        enum Month //Month enum class to hold month names and thier assigned values
        {
            january = 1, february = 2, march = 3, april = 4, may = 5, june = 6, july = 7, august = 8, september = 9, october = 10, november = 11, december = 12
        };
        static void Main(string[] args)
        {
            Console.Write("Enter the Date: ");
            int day = Convert.ToInt16(Console.ReadLine());  //get the day as input integer
            Console.Write("Enter the Month(January, February, March, April, May, June, July, August, September, October, November, December): ");
            string month = Console.ReadLine().ToLower();    //get the month name as input string
            Console.Write("Enter the Year:");
            int year = Convert.ToInt32(Console.ReadLine()); //get the year name as input integer
            //check if the entered year is valid
            if (year < 1 || year > 9999)
            {
                Console.WriteLine("Year is invalid!");
            }
            //check if the entered month is in the Month enum class using Enum.TryParse method 
            else if (Enum.TryParse(month, true, out Month m))
            {
                //check if the entered day is valid with reference to its month for months with max 31 days in them
                if (m == Month.january || m == Month.march || m == Month.may || m == Month.july || m == Month.august || m == Month.october || m == Month.december)
                {
                    if(day < 1 || day > 31)
                    {
                        Console.WriteLine("Day is invalid!");
                    }
                    else
                    {
                        Console.WriteLine("Date(M/D/Y): {0}-{1}-{2}", (int)m, day, year);
                    }
                }
                //check if the entered day is valid with reference to its month for months with max 30 days in them
                else if (m == Month.april || m == Month.june || m == Month.september || m == Month.november)
                {
                    if (day < 1 || day > 30)
                    {
                        Console.WriteLine("Day is invalid!");
                    }
                    else
                    {
                        Console.WriteLine("Date(M/D/Y): {0}-{1}-{2}", (int)m, day, year);
                    }
                }
                //check if the entered day is valid with reference to its month february
                else if (m == Month.february)
                {
                    if (day < 1 || day > 28)
                    {
                        Console.WriteLine("Day is invalid!");
                    }
                    else
                    {
                        Console.WriteLine("Date(M/D/Y): {0}-{1}-{2}", (int)m, day, year);
                    }
                }
            }
            else
            {
                Console.WriteLine("Month is invalid!");
            }
        }
    }
}
