﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task3
{
    class Program
    {
        enum Item //Item enum class to hold Item's names and thier price values
        {
            freezer = 10000, oven = 3000, heater = 2000, geezer = 7000, fridge = 30000
        };
        static void Main(string[] args)
        {
            Console.Write("Enter the Product Name: ");
            string item = Console.ReadLine();    //get the product name as input string
            string itemLower = item.ToLower();  //lower the entered item name format
            //check if the entered product name is in the Item enum class using Enum.TryParse method 
            if (Enum.TryParse(itemLower, true, out Item i))
            {
                Console.WriteLine("Price of {0} is : {1}", item, (int)i);
            }
            else
            {
                Console.WriteLine("Item is invalid!");
            }
        }
    }
}
