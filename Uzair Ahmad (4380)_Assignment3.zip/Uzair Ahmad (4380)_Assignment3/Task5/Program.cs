﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task5
{
    class Program
    {
        enum Operator //Month enum class to hold month names and thier assigned values
        {
            Addition, Subtraction, Multiplication, Division
        };
        static void Main(string[] args)
        {
            Console.Write("Enter value 1: ");
            int value1 = Convert.ToInt16(Console.ReadLine());  //get the first value input integer
            Console.Write("Enter the Operator: ");
            string operate = Console.ReadLine();    //get the operator as input string
            Console.Write("Enter value 1: ");
            int value2 = Convert.ToInt16(Console.ReadLine());  //get the second value input integer
            Operator oper = Operator.Addition;  //bydefault considering addititon operation
            //equate the operator with any of the enum Operator class constnts
            if (operate == "+")
            {
                oper = Operator.Addition;
            }
            if (operate == "-")
            {
                oper = Operator.Subtraction;
            }
            if (operate == "/")
            {
                oper = Operator.Division;
            }
            if (operate == "*")
            {
                oper = Operator.Multiplication;
            }
            //check if the operator is a valid one
            if (operate != "*" && operate != "/" && operate != "+" && operate != "-")
            {
                Console.WriteLine("Invalid operator!");
            }
            //check if the opeator is division and second number is zero
            else if (operate == "/" && value2 == 0)
            {
                Console.WriteLine("Division by zero is undefined");
            }
            //if the operator is one of the enum Operator constant do the relative operation
            else if (oper == Operator.Addition)
            {
                Console.WriteLine(value1 + value2);
            }
            else if (oper == Operator.Subtraction)
            {
                Console.WriteLine(value1 - value2);
            }
            else if (oper == Operator.Division && value2 != 0)
            {
                Console.WriteLine(value1 / value2);
            }
            else if (oper == Operator.Multiplication)
            {
                Console.WriteLine(value1 * value2);
            }
        }
    }
}
