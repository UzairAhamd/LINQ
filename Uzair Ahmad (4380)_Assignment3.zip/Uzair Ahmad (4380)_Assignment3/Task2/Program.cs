﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Task2
{
    class Program
    {
        enum Month //Month enum class to hold month names and thier assigned values
        {
            january, february, march, april, may, june, july, august, september, october, november, december
        };
        static void Main(string[] args)
        {
            foreach(var month in Enum.GetNames(typeof(Month))) //iterate through the enum Month class names constants
            {
                int count=0;    //variable to count the number of characters
                foreach(char c in month)    //loop through the number of characters for a name
                {
                    count++;
                }
                Console.WriteLine("{0} characters in {1}", count, month);
            }
        }
    }
}
